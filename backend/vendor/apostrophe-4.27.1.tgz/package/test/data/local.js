module.exports = {
  overrideTest: 'foo'
};
